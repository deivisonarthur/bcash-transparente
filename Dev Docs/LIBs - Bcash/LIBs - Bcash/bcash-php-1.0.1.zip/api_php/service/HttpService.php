<?php


interface HttpService{

	public static function post($url, $params, $auth);


}



?>