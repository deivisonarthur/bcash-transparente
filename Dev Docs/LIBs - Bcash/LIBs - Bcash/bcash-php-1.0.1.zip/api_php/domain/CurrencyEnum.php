<?php 

class CurrencyEnum{
	
	const REAL = "BRL";
	
}


?>