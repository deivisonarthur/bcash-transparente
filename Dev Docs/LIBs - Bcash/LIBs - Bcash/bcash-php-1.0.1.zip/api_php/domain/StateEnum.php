<?php 

class StateEnum{
	
	const ACRE = "AC";

    const ALAGOAS = "AL";

    const AMAPA = "AP";

    const AMAZONAS = "AM";

    const BAHIA = "BA";

    const CEARA = "CE";

    const DISTRITO_FEDERAL = "DF";

    const ESPIRITO_SANTO = "ES";

    const GOIAS = "GO";

    const MARANHAO = "MA";

    const MATO_GROSSO = "MT";

    const MATO_GROSSO_DO_SUL = "MS";

    const MINAS_GERAIS = "MG";

    const PARA = "PA";

    const PARAIBA = "PB";

    const PARANA = "PR";

    const PERNAMBUCO = "PE";

    const PIAUI = "PI";

    const RIO_DE_JANEIRO = "RJ";

    const RIO_GRANDE_DO_NORTE = "RN";

    const RIO_GRANDE_DO_SUL = "RS";

    const RONDONIA = "RO";

    const RORAIMA = "RR";

    const SANTA_CATARINA = "SC";

    const SAO_PAULO = "SP";

    const SERGIPE = "SE";

    const TOCANTINS = "TO";
	
}

?>