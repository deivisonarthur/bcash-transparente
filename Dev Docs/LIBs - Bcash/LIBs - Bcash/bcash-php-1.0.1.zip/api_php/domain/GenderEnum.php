<?php 
class GenderEnum{
	
	const MALE = "M";
	const FEMALE = "F";

}


?>