<?php

class FreightTypeEnum{

	const E_SEDEX = "E_SEDEX";

	const SEDEX = "SEDEX";

	const PAC = "PAC";

	const ENCOMENDA = "ENCOMENDA";

	const CARTA_REGISTRADA = "CARTA_REGISTRADA";
	
	const CARTA_REGISTRADA = "TRANSPORTADORA";

}


?>